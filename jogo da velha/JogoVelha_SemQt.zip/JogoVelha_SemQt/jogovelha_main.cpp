#include <iostream>
#include "jogovelha.h"

using namespace std;

ostream& operator<<(ostream &O, const JogoVelha &J)
{
  char prov;

  O << "    1   2   3 \n";
  O << "  +---+---+---+";
  prov = J.jogadorVez();
  if (prov=='X' || prov=='O') cout << "   Jogador da vez = " << prov;
  O << endl;
  O << "A | " << J(0,0) << " | " << J(0,1) << " | " << J(0,2) << " |\n";
  O << "  +---+---+---+\n";
  O << "B | " << J(1,0) << " | " << J(1,1) << " | " << J(1,2) << " |\n";
  O << "  +---+---+---+\n";
  O << "C | " << J(2,0) << " | " << J(2,1) << " | " << J(2,2) << " |\n";
  O << "  +---+---+---+";
  prov = J.vencedor();
  if (prov=='X' || prov=='O') cout << "   Vencedor = " << prov;
  O << endl;
  return O;
}

int main(void)
{
  JogoVelha JV;
  bool terminar(false), fim_de_jogo;
  char tecla;

  cout << " +-----------------------+\n";
  cout << " |     JOGO DA VELHA     |\n";
  cout << " +-----------------------+\n";

  do
  {
    cout << JV;
    fim_de_jogo = JV.fimDeJogo();
    do
    {
      cout << (!fim_de_jogo ? "Linha [A-C; " : "[");
      cout << "R=Reiniciar; S=Sair]? ";
      cin >> tecla;
      tecla = toupper(tecla);
    } while ((tecla<'A' || tecla>'C' || fim_de_jogo) && tecla!='R' && tecla!='S');

    if (tecla=='R')
    {
      JV.reiniciar();
    }
    if (tecla=='S')
    {
      terminar = true;
    }
    if (tecla>='A' && tecla<='C' && !fim_de_jogo)
    {
      int i = tecla-'A';  // De 0 a 2
      do
      {
        cout << "Coluna [1-3]? ";
        cin >> tecla;
        tecla = toupper(tecla);
      } while (tecla<'1' || tecla>'3');
      int j = tecla-'1';  // De 0 a 2
      if (JV.jogadaValida(i,j))
      {
        JV.fazerJogada(i,j);
      }
      else
      {
        cout << "Jogada invalida!\n";
      }
    }
  } while(!terminar);
}
