#ifndef _MAINJOGOVELHA_H
#define _MAINJOGOVELHA_H

#include <QMainWindow>
#include <QPixmap>
#include <QLabel>
#include "jogovelha.h"

namespace Ui {
class MainJogoVelha;
}

class MainJogoVelha : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainJogoVelha(QWidget *parent = 0);
    ~MainJogoVelha();

private slots:
    void on_actionSair_triggered();

    void on_actionReiniciar_triggered();

    void on_jogoVelha_cellDoubleClicked(int I, int J);

private:
    Ui::MainJogoVelha *ui;

    JogoVelha JV;

    QLabel NumX;
    QLabel NumO;

    void exibirJogadores();
    void exibirNumeroCasas();
    void exibirImagem(int I, int J);
};

#endif // _MAINJOGOVELHA_H
