#ifndef _JOGOVELHA_H
#define _JOGOVELHA_H
#include <vector>
#include <algorithm>

class JogoVelha
{
private:
  /// As 9 casas do tabuleiro
  std::vector<char> tab;

  /// Quem estah na vez de jogar
  char vez;

  /// Quem venceu o jogo
  char venc;

  /// Retorna referencia que permite alterar o conteudo da casa <I,J>
  inline char& set(int I, int J) {return tab.at(3*I+J);}
public:
  /// Construtor default (tabuleiro vazio)
  JogoVelha();

  /// Limpa o tabuleiro
  void reiniciar();

  /// Retorna o conteudo da casa <I,J>
  inline char at(int I, int J) const {return tab.at(3*I+J);}
  inline char operator()(int I, int J) const {return tab.at(3*I+J);}

  /// Retorna quem estah na vez de jogar (' ' se ninguem)
  inline char jogadorVez() const {return vez;}

  /// Retorna quem ganhou o jogo (' ' se ninguem)
  inline char vencedor() const {return venc;}

  /// Retorna numero de casas X
  inline int numX() const {return count(tab.begin(), tab.end(), 'X');}

  /// Retorna numero de casas O
  inline int numO() const {return count(tab.begin(), tab.end(), 'O');}

  /// Retorna true se alguem ganhou
  /// Se teste for positivo, altera venc e vez <- ' '
  bool vitoria();

  /// Retorna true se nao pode mais ganhar
  /// (vitoria ou tabuleiro completo)
  /// Se teste for positivo, vez <- ' '
  bool fimDeJogo();

  /// Testa se o jogador da vez pode jogar na casa <I,J>
  bool jogadaValida(int I, int J) const;

  /// Coloca a marca do jogador da vez na casa <I,J>
  void fazerJogada(int I, int J);
};

#endif // _JOGOVELHA_H
