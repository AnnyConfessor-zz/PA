#include <cstdlib>   /* srand, rand */
#include <fstream>
#include <string>
#include <stack>
#include <time.h>

#include "sudoku.h"

using namespace std;

/**********************************************************
 * CLASSE JOGADA                                          *
 **********************************************************/

/// Construtor (por default, cria Jogada que termina o jogo)
Jogada::Jogada(int I, int J, int V)
{
  setCell(I,J);
  setValue(V);
}

/// Fixa as coordenadas de uma jogada
/// Por default, cria Jogada que termina o jogo
void Jogada::setCell(int I, int J)
{
  if (I<0 || I>8) I=-1;
  if (J<0 || J>8) J=-1;
  i = I;
  j = J;
}

/// Fixa o valor de uma jogada
/// Por default, cria Jogada que termina o jogo
void Jogada::setValue(int V)
{
  if (V<0 || V>9) V=-1;
  v = V;
}

/**********************************************************
 * CLASSE SUDOKU                                          *
 **********************************************************/

/// Limpa o tabuleiro
void Sudoku::limpar()
{
  for (unsigned i=0; i<9; i++) for (unsigned j=0; j<9; j++)
  {
    set(i,j) = 0;
  }
}

/// Gera um novo tabuleiro aleatorio, com solucao unica e sem pedras desnecessarias.
void Sudoku::gerar()
{
  int i,j,k,n;
  srand(time(NULL));

  // Gera um tabuleiro vazio
  Sudoku completo;

  // Preenche os 3 blocos da diagonal principal
  for (n=0; n<3; n++)
  {
    // A ordem em que os numeros serao colocados no bloco
    int ordem[] = {1,2,3,4,5,6,7,8,9};
    // Faz 10 permutacoes aleatorias no vetor ordem
    for (k=0; k<10; k++)
    {
      i = rand()%9;
      j = rand()%9;
      swap(ordem[i],ordem[j]);
    }
    // Coloca os numeros no bloco
    for (i=0; i<3; i++) for (j=0; j<3; j++)
    {
      completo.set(3*n+i,3*n+j) = ordem[3*i+j];
    }
  }

  if (!completo.resolver(false))
  {
    // Tem um erro grande no programa!
    // Nao conseguiu resolver um tabuleiro consistente!!!
    return;
  }

  // Inicializa o melhor tabuleiro como sendo o completo
  // Em seguida, inicia um laco:
  // Remove uma casa do melhor tabuleiro e verifica se foi
  // encontrada a mesma solucao (completo), com solucao unica
  // Refaz esse procedimento ateh que tente 5 vezes consecutivas
  // remover e nao consiga mais a mesma solucao unica
  Sudoku melhor(completo);
  Sudoku atual,teste;

  n = 0;
  do
  {
    atual = melhor;
    // Elimina uma pedra aleatoria
    do
    {
      i = rand()%9;
      j = rand()%9;
    } while (atual(i,j)==0);
    atual.set(i,j)=0;
    // Tenta resolver o atual
    teste = atual;
    k = teste.resolver(false,false);
    if (k==1 && teste==completo)
    {
      melhor = atual;
      n=0;
    }
    else n++;
  } while (n<5);

  // Por fim, tenta remover todas as pedras de forma sistematica
  // (nao aleatoria). Remove todas aquelas para as quais a solucao
  // encontrada apos remocao seja unica e a mesma de antes da remocao
  for (i=0; i<9; i++) for (j=0; j<9; j++) if (melhor(i,j) != 0)
  {
    atual = melhor;
    // Elimina a pedra i,j
    atual.set(i,j)=0;
    // Tenta resolver o atual
    teste = atual;
    k = teste.resolver(false,false);
    if (k==1 && teste==completo)
    {
      melhor = atual;
    }
  }

  *this = melhor;
}

/// Cria um tabuleiro com o conteudo do arquivo nome_arq
/// Caso nao consiga ler do arquivo, retorna tabuleiro vazio
/// ou lido parcialmente, caso contrario
Sudoku::Sudoku(const char *nome_arq): tab(81)
{
  // Comeca com tabuleiro vazio
  limpar();

  // Le o tabuleiro inicial de arquivo
  ifstream arq(nome_arq);
  if (!arq.is_open())
  {
    return;
  }

  string prov;
  int valor;

  arq >> prov;
  if (prov != "SUDOKU")
  {
    return;
  }

  // Leh as pedras do arquivo
  for (unsigned i=0; i<9; i++) for (unsigned j=0; j<9; j++)
  {
    arq >> valor;
    if (valor != 0)
    {
      Jogada J(i,j,valor);
      fazer_jogada(J);
    }
  }
  arq.close();
}

/// Compara se dois tabuleiros sao iguais
bool Sudoku::operator==(const Sudoku &S) const
{
  for (unsigned i=0; i<9; i++) for (unsigned j=0; j<9; j++)
  {
    if (at(i,j) != S(i,j)) return false;
  }
  return true;
}

/// Testa se a jogada J eh possivel para o tabuleiro
bool Sudoku::jogada_valida(Jogada J) const
{
  unsigned i,j;
  // Testar a jogada
  if (!J.jogada()) return false;

  // Testar se a casa nao estah vazia
  if (at(J.i,J.j) != 0) return false;

  // Testar a linha
  for (i=0; i<9; i++)
  {
    if (at(i,J.j) == J.v) return false;
  }
  // Testar a coluna
  for (j=0; j<9; j++)
  {
    if (at(J.i,j) == J.v) return false;
  }
  // Testar o bloco
  unsigned iIni = 3*(J.i/3);
  unsigned jIni = 3*(J.j/3);
  for (i=0; i<3; i++) for (j=0; j<3; j++)
  {
    if (at(iIni+i,jIni+j) == J.v) return false;
  }
  return true;
}

/// Testa se a jogada J eh um apagamento valido de uma casa para o tabuleiro,
/// levando em conta o tabuleiro original (nao eh permitido apagar casas que
/// estavam preenchidas no tabuleiro original)
bool Sudoku::apagamento_valido(Jogada J, const Sudoku &Origem) const
{
  // Testar a jogada
  if (!J.apagamento()) return false;

  // Testar se a casa estah vazia
  if (at(J.i,J.j) == 0) return false;

  // Testar se a casa do tabuleiro original nao estah vazia
  if (Origem(J.i,J.j) != 0) return false;

  return true;
}

/// Testa se o tabuleiro estah completo (fim de jogo)
bool Sudoku::fim_de_jogo() const
{
  for (unsigned i=0; i<9; i++) for (unsigned j=0; j<9; j++)
  {
    if (at(i,j) == 0) return false;
  }
  return true;
}

/// Retorna o numero de casas vazias no tabuleiro
unsigned Sudoku::num_casas_vazias() const
{
  unsigned N(0);
  for (unsigned i=0; i<9; i++) for (unsigned j=0; j<9; j++)
  {
    if (at(i,j) == 0) N++;
  }
  return N;
}

/// Calcula o numero de possibilidades para preencher a casa (i,j)
/// utilizando apenas as regras "faceis" (linha, coluna e bloco)
/// Se houver uma unica possibilidade de preenchimento, retorna o valor (1 a 9)
/// Se nao houver nenhuma possibilidade de preenchimento, retorna 0, o que
/// indica que o tabuleiro nao tem solucao
/// Se houver mais de uma possibilidade de preenchimento, retorna um numero
/// negativo (<= -2), cujo modulo eh o numero de possibilidades
int Sudoku::numero_possibilidades(unsigned i, unsigned j) const
{
  // A principio, todos os 9 valores de jogada sao possiveis
  bool valor_possivel[]={true,true,true,true,true,true,true,true,true};
  unsigned ii,I,jj,J,k;

  // Se a casa jah estiver preenchida, nao hah nenhuma possibilidade
  if (at(i,j)!=0) return -1;

  // Varre a linha
  for (k=0; k<9; k++)
  {
    if (at(i,k)>0) valor_possivel[at(i,k)-1] = false;
  }

  // Varre a coluna
  for (k=0; k<9; k++)
  {
    if (at(k,j)>0) valor_possivel[at(k,j)-1] = false;
  }

  // Varre a quadra
  I = 3*(i/3);
  J = 3*(j/3);
  for (ii=0; ii<3; ii++) for (jj=0; jj<3; jj++)
  {
    if (at(I+ii,J+jj)>0) valor_possivel[at(I+ii,J+jj)-1] = false;
  }

  // Conta o numero de valores possiveis
  unsigned num_possiveis=0;
  for (k=0; k<9; k++)
  {
    if (valor_possivel[k]) num_possiveis++;
  }

  // Nao hah nenhum valor possivel
  if (num_possiveis == 0) return 0;

  // Hah mais de um valor possivel
  if (num_possiveis > 1) return -num_possiveis;

  // Hah uma unica possibilidade de preenchimento da casa
  // Retorna o valor possivel
  k = 0;
  while (!valor_possivel[k]) k++;
  return k+1;
}

/// Preenche todas as casas "faceis" do tabuleiro, ou seja, aquelas que tem um
/// unico valor possivel pelas regras do Sudoku
/// Retorna o numero de casas adicionais preenhidas (0 ou >0) ou entao
/// retorna <0 se houver alguma casa sem possibilidade de jogada (tabuleiro insoluvel)
/// Quando retorna um valor negativo (ou seja, o tabuleiro eh insoluvel), o numero
/// retornado serah o negativo do numero de casas preenchidas. Caso nenhuma casa
/// tenha sido preeenchida e o tabuleiro seja insoluvel, serah retornado um numero
/// negativo menor que -81.
int Sudoku::resolver_casas_faceis()
{
  unsigned num_casas=0;
  bool insoluvel(false),resolveu_alguma;
  unsigned i,j;
  int valor;

  do
  {
    resolveu_alguma = false;
    for (i=0; i<9; i++) for (j=0; j<9; j++) if (at(i,j)==0)
    {
      valor = numero_possibilidades(i,j);
      if (valor == 0)
      {
        // Hah uma casa na qual nenhum valor eh possivel
        // O tabuleiro nao tem solucao
        insoluvel = true;
      }
      if (valor > 0)
      {
        set(i,j) = valor;
        resolveu_alguma = true;
        num_casas++;
      }
    }
  } while (resolveu_alguma);
  if (insoluvel)
  {
    if (num_casas==0) return -666;
    return (-num_casas);
  }
  return num_casas;
}

/// Determina automaticamente a solucao do tabuleiro (preenche as casas vazias).
/// O parametro com_exibicao controla se o algoritmo deve (true) ou nao (false)
/// exibir os tabuleiros analisados e o numero de nohs durante o algoritmo.
/// O parametro "basta_primeira_solucao" fixa se o algoritmo deve (true) ou nao (false)
/// retornar assim que encontrar a primeira solucao, sem verificar se existe outra.
/// Retorna 0 se nao foi encontrada solucao, 1 se foi encontrada uma solucao unica
/// e >1 se existem mais de uma solucao (essa ultima possibilidade de retorno soh
/// existe se o parametro basta_primeira_solucao for false.
int Sudoku::resolver(bool com_exibicao, bool basta_primeira_solucao)
{
  // As constantes de compilacao (#define) a seguir permitem modificar o comportamento
  // do algoritmo de resolucao da classe Sudoku

  // Ter (descomentar) ou nao (comentar) comportamento aleatorio na resolucao
  // Sem comportamento aleatorio, a sequencia de geracao de sucessores sempre eh feita na
  // ordem 1,2,...,9. Com comportamento aleatorio, a seguencia eh sorteada a cada resolucao
  #define RESOLVER_ALEATORIO

  // Fazer (descomentar) ou n�o (comentar) o preenchimento das casas faceis de cada tabuleiro
  // sendo analisado antes de gerar os sucessores
  #define RESOLVER_CASAS_FACEIS_PREVIAMENTE

  // Gera sucessores preenchendo a casa com menos possibilidades de preenchimento (descomentar)
  // ou preenchendo sempre a primeira vaga (comentar)
  #define RESOLVER_OTIMIZADO

  // Numero de iteracoes durante as quais sempre se exibe o tabuleiro. Atingido esse numero,
  // passa a soh exibir um novo tabuleiro a cada NUMERO_ITERACOES_EXIBIDAS iteracoes
  #define NUMERO_ITERACOES_EXIBIDAS 1000

  // Testa se jah nao estah resolvido desde o inicio
  if (this->fim_de_jogo()) return 1;

  // aberto eh a pilha de tabuleiros ainda nao analisados, a partir do qual
  // serah executado o algoritmo de resolucao por busca em profundidade (backtracking)
  stack<Sudoku> aberto;
  // Inicializa aberto com o tabuleiro inicial
  aberto.push(*this);

  // Numero de tabuleiros testados e gerados ateh o momento
  int num_tab_testados(0), num_tab_gerados(1);

  // Numero de solucoes encontradas ateh o momento
  int num_solucoes_encontradas(0);

  // Melhor serah o tabuleiro encontrado com mais casas preenchidas ateh o momento
  // Inicializa com o tabuleiro inicial
  Sudoku Melhor(*this);
  // Numero de casas vazias do melhor tabuleiro ateh o momento
  int num_vazias_melhor=Melhor.num_casas_vazias();

  // A ordem em que os sucessores sao gerados
  int ordem[] = {1,2,3,4,5,6,7,8,9};

  // Flag que assinala o fim do algoritmo
  bool encerrar_algoritmo;

  // Tabuleiro sendo analisado no momento
  Sudoku S;
  // Numero de casas resolvidas facilmente e de casas vazias no tabuleiro sendo analisado
  int num_resolvidas, num_vazias;

  #ifdef RESOLVER_OTIMIZADO
  // Numero de possibilidades de preenchimento de uma casa
  int num_possib;
  // Possibilidades de preenchimento da casa com menor numero de possibilidades
  int menor_num_possib;
  #endif

  // Variaveis auxiliares
  int I,J,i,j,k;

  // Fax 10 permutacoes aleatorias no vetor ordem
  // Com isso, cada resolucao pode gerar uma solucao diferente
  #ifdef RESOLVER_ALEATORIO
  srand(time(NULL));
  for (k=0; k<10; k++)
  {
    i = rand()%9;
    j = rand()%9;
    swap(ordem[i],ordem[j]);
  }
  #endif

  do
  {
    S = aberto.top();
    aberto.pop();

    #ifdef RESOLVER_CASAS_FACEIS_PREVIAMENTE
    // Resolve as casas faceis
    num_resolvidas = S.resolver_casas_faceis();
    #else
    num_resolvidas = 0;
    #endif

    num_vazias = S.num_casas_vazias();
    if (num_vazias < num_vazias_melhor)
    {
      Melhor = S;
      num_vazias_melhor = num_vazias;
    }
    if (num_vazias == 0) num_solucoes_encontradas++;
    num_tab_testados++;

    // Soh gera sucessores se nao for solucao e nao for insoluvel
    if (num_vazias!=0 && num_resolvidas>=0)
    {
      I = J = -1;
      #ifdef RESOLVER_OTIMIZADO
      menor_num_possib = 10;
      #endif
      for (i=0; i<9; i++) for (j=0;j<9; j++) if (S.at(i,j)==0)
      {
        #ifdef RESOLVER_OTIMIZADO
        // Escolhe a casa (I,J) com menor numero de possibilidades de preenchimento
        num_possib = S.numero_possibilidades(i,j);
        // Soh existe uma possibilidade de preenchimento
        if (num_possib >= 1) num_possib = 1;
        // Existem varias possibilidades de preenchimento
        if (num_possib <= -2) num_possib = abs(num_possib);

        if (num_possib < 1)
        {
          // Tabuleiro insoluvel, pois existe uma casa insoluvel
          I = J = -1;
          // Sai dos lacos for
          i = j = 10;
        }
        else if (num_possib < menor_num_possib)
        {
          I = i;
          J = j;
          menor_num_possib = num_possib;
        }
        #else
        // Escolhe a primeira casa livre
        I = i;
        J = j;
        // Sai dos lacos for
        i = j = 10;
        #endif
      }

      if (I>=0 && I<9 && J>=0 && J<9)  // Existe casa a ser preenchida
      {
        // Gera todas as jogadas validas na casa escolhida
        Jogada Jog(I,J);

        // Testa todos os valores validos para uma jogada na posicao (I,J)
        for (k=0; k<9; k++)
        {
          Jog.v = ordem[k];
          if (S.jogada_valida(Jog))
          {
            Sudoku Suc(S);

            Suc.fazer_jogada(Jog);
            aberto.push(Suc);
            num_tab_gerados++;
          }
        }
      }
    }
    // Exibe o andamento do algoritmo de resolucao
    if (com_exibicao &&
        (num_tab_gerados<NUMERO_ITERACOES_EXIBIDAS || num_tab_gerados%NUMERO_ITERACOES_EXIBIDAS==0))
    {
      S.exibir();
      S.exibir_andamento(num_tab_testados, num_tab_gerados, aberto.size());
    }
    // O algoritmo encerra em tres casos:
    // a) nao existe mais nenhum tabuleiro para expandir;
    // b) jah foram encontradas 2 ou mais solucoes; ou
    // c) jah foi encontrada uma solucao e nao precisa testar se existem multiplas solucoes
    encerrar_algoritmo = aberto.empty() ||
        num_solucoes_encontradas>=2 ||
        (num_solucoes_encontradas>=1 && basta_primeira_solucao);

  } while(!encerrar_algoritmo);
  if (num_solucoes_encontradas >= 1) *this = Melhor;
  if (com_exibicao)
  {
    Melhor.exibir();
    Melhor.exibir_andamento(num_tab_testados, num_tab_gerados, aberto.size());
  }
  return num_solucoes_encontradas;
}
