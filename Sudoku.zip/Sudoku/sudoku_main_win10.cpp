#include <iostream>
#include <cstdlib>
#include <conio.h>
#include "console.h"
#include "sudoku.h"

using namespace std;

/* ===================================================================
AS FUNCOES DE ENTRADA/SAIDA FORMATADA
=================================================================== */

/// Imprime msg e espera que o usuario digite uma tecla
void espera_tecla()
{
  Term.exibir_cursor();
  Term.gotoYX(22,13);
  cout << "Qualquer tecla para continuar: ";
  getch();
  cout << endl;
  Term.gotoYX(22,1);
  Term.limpar_linha();
}

/// Desenha as linhas dos tabuleiros direito (incial=true) e esquerdo (inicial=false)
void desenha_moldura(bool inicial)
{
  Term.ocultar_cursor();
  int J = (inicial ? 29 : 1);

  // Muda para o modo de desenho de linhas
  Term.modo_linhas();

  for (unsigned i=7; i<=17; i++)
  {
    Term.gotoYX(i,J+1);
    cout << "x       x       x       x";  // |   |   |   |
  }
  for (unsigned i=0; i<4; i++)
  {
    Term.gotoYX(6,J+1);
    cout << "lqqqqqqqwqqqqqqqwqqqqqqqk";  // -------------
    Term.gotoYX(10,J+1);
    cout << "tqqqqqqqnqqqqqqqnqqqqqqqu";  // -------------
    Term.gotoYX(14,J+1);
    cout << "tqqqqqqqnqqqqqqqnqqqqqqqu";  // -------------
    Term.gotoYX(18,J+1);
    cout << "mqqqqqqqvqqqqqqqvqqqqqqqj";  // -------------
  }

  // Retorna para o modo normal
  Term.modo_texto();

  // Imprime as etiquetas
  for (unsigned i=0; i<9; i++)
  {
    Term.gotoYX(7+i+i/3,J);
    cout << char('A'+i);
    Term.gotoYX(5,J+3+2*(i+i/3));
    cout << i+1;
  }
}

/// Desenha os textos iniciais e molduras dos tabuleiros
void exibir_cabecalho()
{
  if (!Term.formatado())
  {
    cerr << "O terminal nao permite saida formatada!\n";
    cerr << "Este arquivo soh pode ser executado no Windows 10\n";
    cerr << "Compile com o arquivo na versao nao formatada\n";
    cerr << "Saindo...\n";
    exit(1);
  }

  Term.tela_alternativa();
  Term.clrscr();

  Term.modo_linhas();
  Term.cores(CONSOLE_CORES::BRIGHT_YELLOW, CONSOLE_CORES::DEFAULT);
  cout << " lqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqk \n";
  cout << " x                                                   x \n";
  cout << " mqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqj \n";
  Term.modo_texto();
  Term.gotoYX(2,3);
  Term.cores(CONSOLE_CORES::BRIGHT_BLACK, CONSOLE_CORES::BRIGHT_YELLOW);
  cout << "                      SUDOKU                       ";
  Term.cores(CONSOLE_CORES::BRIGHT_WHITE, CONSOLE_CORES::DEFAULT);
  Term.gotoYX(4,7);
  cout << "TABULEIRO ATUAL";
  Term.gotoYX(4,34);
  cout << "TABULEIRO INICIAL";
  Term.cores(CONSOLE_CORES::DEFAULT, CONSOLE_CORES::DEFAULT);

  desenha_moldura(true);
  desenha_moldura(false);
}

/// Informa que o tabuleiro foi resolvido
void exibir_congratulacoes()
{
  Term.gotoYX(20,16);
  Term.limpar_linha();
  Term.cores(CONSOLE_CORES::BRIGHT_GREEN, CONSOLE_CORES::DEFAULT);
  cout << "PARABENS! JOGO CONCLUIDO!";
  Term.cores(CONSOLE_CORES::DEFAULT, CONSOLE_CORES::DEFAULT);
  espera_tecla();
  Term.gotoYX(20,4);
  Term.limpar_linha();
}

/// Exibe o numero de casas faceis preenchidas imediatamente
void exibir_preenchidas(int N)
{
  if (N != 0)
  {
    unsigned NN = abs(N);
    if (NN <= 81)
    {
      Term.gotoYX(19,4);
      cout << NN << ' ';
      if (NN>1)
      {
        cout << "casas preenchidas.";
      }
      else
      {
        cout << "casa preenchida.";
      }
    }
    if (N < 0)
    {
      Term.gotoYX(20,4);
      cout << "O TABULEIRO NAO TEM SOLUCAO!\n";
    }
    espera_tecla();
    Term.gotoYX(20,1);
    Term.limpar_linha();
    Term.gotoYX(19,1);
    Term.limpar_linha();
  }
}

/// Espera para que o usuario veja a resposta do algoritmo de resolucao
void exibir_resposta()
{
  espera_tecla();
  Term.gotoYX(20,1);
  Term.limpar_linha();
  Term.gotoYX(19,1);
  Term.limpar_linha();
}

/// Encerra o modo de exibicao formatada
void encerra_exibicao()
{
  Term.tela_normal();
}

int main(void)
{
  Sudoku Origem("sudoku.txt"),S(Origem);
  Jogada J;

  exibir_cabecalho();

  Origem.exibir_origem();
  S.exibir();

  do
  {
    do
    {
      J.ler();
    } while(!J.jogada() && !J.apagamento() &&
            !J.resolver_jogo() && !J.preencher_jogo() &&
            !J.novo() && !J.voltar() &&
            !J.fim_de_jogo());
    if (J.jogada())
    {
      S.fazer_jogada(J);
    }
    if (J.apagamento())
    {
      S.apagar_jogada(J,Origem);
    }
    if (J.preencher_jogo())
    {
      S.exibir_origem();
      int N = S.resolver_casas_faceis();
      S.exibir();
      exibir_preenchidas(N);
      Origem.exibir_origem();
    }
    if (J.resolver_jogo())
    {
      S.exibir_origem();
      S.resolver();
      exibir_resposta();
      Origem.exibir_origem();
    }
    if (J.novo())
    {
      Origem.gerar();
      S=Origem;
      Origem.exibir_origem();
    }
    if (J.voltar())
    {
      S = Origem;
    }
    S.exibir();
    if (!J.fim_de_jogo() && S.fim_de_jogo())
    {
      exibir_congratulacoes();
    }
  } while(!J.fim_de_jogo());

  encerra_exibicao();
}
