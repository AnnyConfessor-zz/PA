#ifndef _MATRIZ_H_
#define _MATRIZ_H_

#include <iostream>

using namespace std;

class Matriz
{
private:
  unsigned NL, NC;
  double **x;
  void criar(unsigned numL, unsigned numC);
  void copiar(const Matriz &N);
  void limpar();
public:
  // Construtores e destrutores
  inline Matriz(): NL(0), NC(0), x(NULL) {}  // Default
  inline Matriz(unsigned numL, unsigned numC) {criar(numL, numC);}  // Espec�fico
  inline Matriz(const Matriz &N) {copiar(N);}  // Copia
  inline ~Matriz() {limpar();}

  // Funcoes de consulta
  inline unsigned getNumL(void) const {return NL;}
  inline unsigned getNumC(void) const {return NC;}
  double at(unsigned i, unsigned j) const;
  // Funcao de fixacao de valor
  double& set(unsigned i, unsigned j);

  // Entrada e saida de dados
  friend ostream &operator<<(ostream &X, const Matriz &N);
  friend istream &operator>>(istream &X, Matriz &N);

  // Atribuicao
  void operator=(const Matriz &N);

  // Operadores
  Matriz operator+(const Matriz &N) const;
  inline const Matriz &operator+() const {return *this;}
  Matriz operator-(const Matriz &N) const;
  Matriz operator-() const;
  Matriz operator*(const Matriz &N) const;

  // Operacoes matriciais
  Matriz operator!(void) const;  // Transposta
  double determinante(void) const;
  Matriz operator~(void) const;  // Inversa
  inline Matriz operator/(const Matriz &N) const {return operator*(~N);}
};

// Declaracao de algumas operacoes matriciais que jah foram declaradas como
// metodos utilizando uma notacao alternativa, como funcoes
// Por exemplo, se A eh uma matriz, pode-se usar:
// A.determinante(); ou
// determinante(A);
// AS funcoes simplesmente chamam o metodo correspondente
// Notar que as funcoes nao precisam ser declaradas friend pq nao usam membros privados
inline Matriz transposta(const Matriz &N) {return !N;}
inline double determinante(const Matriz &N) {return N.determinante();}
inline Matriz inversa(const Matriz &N) {return ~N;}

#endif // _MATRIZ_H_
