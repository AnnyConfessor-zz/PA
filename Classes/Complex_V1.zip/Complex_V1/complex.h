#include <iostream>

// Tipo Complex

class Complex
{
private:
  double real, imag;
public:
  /// Construtores
  Complex();
  Complex(double R);
  Complex(double R, double I);

  inline double getReal() const {return real;}
  inline double getImag() const {return imag;}

  void ler();
  void imprimir() const;
  Complex operator+(const Complex &C2) const;
  Complex operator*(const Complex &C2) const;
};

